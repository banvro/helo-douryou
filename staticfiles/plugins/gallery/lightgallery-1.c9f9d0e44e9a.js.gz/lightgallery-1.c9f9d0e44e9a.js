 lightGallery(document.getElementById('lightgallery'));
 lightGallery(document.getElementById('lightgalleryq'));
 lightGallery(document.getElementById('lightgalleryw'));
 lightGallery(document.getElementById('lightgallerye'));
 lightGallery(document.getElementById('lightgalleryr'));
 lightGallery(document.getElementById('lightgalleryt'));