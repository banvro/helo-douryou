/*!
 Bootstrap integration for DataTables' Buttons
 ©2016 SpryMedia Ltd - datatables.net/license
*/
(function(c) { "function" === typeof define && define.amd ? define(["jquery", "datatables.net-bs5", "datatables.net-buttons"], function(a) { return c(a, window, document) }) : "object" === typeof exports ? module.exports = function(a, b) { a || (a = window);
        b && b.fn.dataTable || (b = require("datatables.net-bs5")(a, b).$);
        b.fn.dataTable.Buttons || require("datatables.net-buttons")(a, b); return c(b, a, a.document) } : c(jQuery, window, document) })(function(c, a, b, f) {
    a = c.fn.dataTable;
    c.extend(!0, a.Buttons.defaults, {
        dom: {
            container: { className: "dt-buttons btn-group flex-wrap" },
            button: { className: "btn btn-primary" },
            collection: { tag: "div", className: "dropdown-menu", button: { tag: "a", className: "dt-button dropdown-item", active: "active", disabled: "disabled" } }
        },
        buttonCreated: function(e, d) { return e.buttons ? c('<div class="btn-group"/>').append(d) : d }
    });
    a.ext.buttons.collection.className += " dropdown-toggle";
    a.ext.buttons.collection.rightAlignClassName = "dropdown-menu-right";
    return a.Buttons
});